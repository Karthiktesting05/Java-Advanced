package ObjectandClass;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sample a = new Sample();
		a.testing();
		
	}
	
	
	public void testing(){
		
		//local variable
		int a = 10;
		System.out.println(a);
		
	}

}
