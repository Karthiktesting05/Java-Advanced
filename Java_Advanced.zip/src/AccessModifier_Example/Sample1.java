package AccessModifier_Example;

import AccessModifier.AccessModifier;

public class Sample1 extends AccessModifier{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sample1 AM = new Sample1();
		
		AM.PROTECTEDMETHOD();
		
		AM.PUBLICMETHOD();
		
	}

}
