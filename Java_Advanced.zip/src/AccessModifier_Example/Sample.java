package AccessModifier_Example;

import AccessModifier.AccessModifier;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccessModifier AM = new AccessModifier();
		
		AM.PUBLICMETHOD();
	
		
	}

}
