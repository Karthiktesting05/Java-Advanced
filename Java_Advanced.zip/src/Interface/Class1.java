package Interface;

public interface Class1 extends Class4 {

	//Interface can have only abstract methods.
	//Interface supports multiple inheritance.
	void students();
	
	//Abstract can have both abstract and non abstract methods,
	//It doesn't support multiple inheritance.

}
