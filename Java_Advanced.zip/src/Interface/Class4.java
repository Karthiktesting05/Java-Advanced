package Interface;

public interface Class4 {

	//Interface can have only abstract methods.
	public void Employees();

	
}
