package Inheritance;

public class Sample {

	static String value = "Selenium";
	
	public static void testing(){
		
		System.out.println("Another class file");
	}
}
