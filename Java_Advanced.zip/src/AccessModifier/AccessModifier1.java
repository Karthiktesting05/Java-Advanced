package AccessModifier;

public class AccessModifier1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccessModifier AM = new AccessModifier();
		
		AM.PUBLICMETHOD();
		
		AM.PROTECTEDMETHOD();
		
		AM.DEFAULTMETHOD();
			
		
	}

}
