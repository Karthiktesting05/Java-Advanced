package Encapsulation;

//WebServices
public class EncapsulationClass {

	private String CustomerName;

	// Get is used to retrieve the data
	public String getName() {

		return CustomerName;

	}

	// Set is used to insert the data
	public void setName(String Value) {

		this.CustomerName = Value;
	}

}
