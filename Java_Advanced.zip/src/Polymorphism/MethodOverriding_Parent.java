package Polymorphism;

public class MethodOverriding_Parent {

	 //Data type
	 int speedlimit = 100;
	 
	 // Method Name = running
	public void running(){
		
		System.out.println("Vechile is running");
	}
	
	
	//Another Method
	public void Training(){
		
		System.out.println("Selenium Training Session");
	}
	
	
}
