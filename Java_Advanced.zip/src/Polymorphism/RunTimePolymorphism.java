package Polymorphism;

public class RunTimePolymorphism {

	public void running(){
		
		System.out.println("Running on the road");
	}
	
	
}
